export const products = [
    {
        id: 0,
        name: "Samsung",
        price: 799,
        description: "A large phone"
    },
    {
        id: 1,
        name: "Vivo",
        price: 99,
        description: "A large phone"
    },
    {
        id: 2,
        name: "Phone XL",
        price: 999,
        description: "A large phone"
    }
]